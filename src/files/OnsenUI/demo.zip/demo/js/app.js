'use strict';

angular.module('myApp', [ 'ngTouch', 'onsen.directives']);
