function DetailController($scope, Data){
    $scope.item = Data.selectedItem;   
}